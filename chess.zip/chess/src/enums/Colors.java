package enums;

public enum Colors {
	Black, White
}
